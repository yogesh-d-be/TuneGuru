import { createContext } from "react";

const NavContext = createContext(null);

export default NavContext;