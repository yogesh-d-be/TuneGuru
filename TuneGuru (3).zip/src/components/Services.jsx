import React  from "react";
// import { Link } from "react-router-dom";
// import Parallax from "./Parallax";
import Login from "./Login";
function Services(){

return(
<>
<Login/>
</>
)

}

export default Services;