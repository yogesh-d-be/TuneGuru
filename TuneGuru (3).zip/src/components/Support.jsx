import React  from "react";
// import { Link } from "react-router-dom";
import Login from "./Login";
function Support(){

return(
<>
<Login/>
</>
)

}

export default Support;