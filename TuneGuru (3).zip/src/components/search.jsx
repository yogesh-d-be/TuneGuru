import React  from "react";
// import { FaSearch } from "react-icons/fa";



function Search() {

    return(
        // <div className="border border-black rounded-md width"><FaSearch/></div>
      
           <></>
            
      
    )
    
}
export default Search;