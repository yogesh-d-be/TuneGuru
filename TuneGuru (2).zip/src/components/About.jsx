import React, { useContext, useState }  from "react";
// import { Link } from "react-router-dom";
// import NavContext from "./NavContext";
// import Navbar from "./Navbar";
// import ParallaxContext from "./ParallaxContext";
import Parallax from "./Parallax";

import Navbar from "./Navbar";
import Home from "./Home";
import Login from "./Login";
import LoginModal from "./LoginModal";
// import {useLocation} from "react-router-dom";


function About(){
    
    
return(
<>
<Login/>

</>
)

}

export default About;