import React  from "react";
// import { Link } from "react-router-dom";
import Login from "./Login";
function Register(){

return(
<>
<Login/>
</>
)

}

export default Register;