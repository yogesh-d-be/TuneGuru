import React, { useState }  from "react";
import { Link , useNavigate} from "react-router-dom";
import { MdCancel } from "react-icons/md";
import { RxHamburgerMenu } from "react-icons/rx";
import LoginModal from "./LoginModal";
import Login from "./Login";
// import Search from "./search"

import "./Navbar.css";
// import { createContext } from "react";
// export const NavContext = createContext()
// import NavContext from "./NavContext"

function Navbar({openLogin}){
   const history = useNavigate();
       const [menu, setMenu] = useState(false)
    const [login, setLogin] = useState(false);

    const searchClick = (e) =>{
        e.stopPropagation();
        setMenu(true);
    }
    
    // const openLogin = () =>{
    //     setLogin(true);
    // }
    // const closeLogin = () =>{
    //     setLogin(false);
    // }
    // const bgblur = ()=>{
        //     bgeffect = {menu , "bgblur"  "normal" }
        // }
        //search click function used to prevent and stop the automatic close of navbar(mob view) when i click the search input 
    return(
        // <NavContext.Provider value={Navbar}>
        <>
        
        <div className=" relative flex justify-between h-20 items-center nav  z-20">
           
                <img src= {require('../assests/images/Tuneguru logo.png')} className="w-40 left-0 rounded-lg logo " alt="logo" />
                {/* <div className="menu" onClick={() =>{
                    setMenu(!menu)
                }}>
                    <span></span>
                    <span></span>
                    <span></span>
                    
                </div> */}
            <div className="nav-items">
            <ul className={menu ? "mob" : "desk" } onClick={()=>setMenu(false)}>
           
                    {/* <li className="flex"><Link to="/" className="no-underline ">Home</Link></li> */}
                 <li  className="list-none list"> <input type="text" placeholder="Search..." className=" pl-4 p-1 border-2 border-black outline-none rounded-2xl " onClick={searchClick}/></li> 
                 <li  className="list-none list"><Link to="/" className="no-underline block  px-4 py-2 rounded-md text-white  mr-2 link active:bg-blue-700 ">Home</Link></li> 
                <li  className="list-none list"><Link to="/services" className="no-underline block px-4 py-2 rounded-md text-white  mr-2 link">Services</Link></li>
                <li  className="list-none list"><Link to="/about" className="no-underline block px-4 py-2 rounded-md text-white  mr-2 link" >About</Link></li>
                <li  className="list-none list"><Link to="/support" className="no-underline block px-4 py-2 rounded-md text-white  mr-2 link">Support</Link></li>
                <li  className="list-none list"><Link to="/register" className="no-underline block px-4 py-2 rounded-md text-white mr-2 link">Register</Link></li>
                <li  className="list-none list"><button className="login"><span className="no-underline block px-4 py-2  rounded-md text-white  bg-orange-600" onClick={openLogin} >Login</span></button></li>
                {/* <li  className="list-none list">
                    <button
                    onClick={openLogin}
                    className=" login no-underline block px-4 py-2  rounded-md text-white  bg-orange-600">Login
                     </button>
                </li>  */}

            </ul>
            
           
            <button className="menu-icon" onClick={()=>setMenu(!menu)}>
                {menu ? (<MdCancel className="text-white text-3xl cancel-icon animate-cancel" />) : (<RxHamburgerMenu className="text-white text-3xl hammenu-icon animate-hamburger" />) }
            </button>
        </div>
                {/* <div>
                    <img src={require('../assests/gif/Hammer gif.gif')} alt="" />
                </div> */}
        
        </div>
        {/* <Login openModal={login} closeModal={closeLogin}/> */}
        {/* {login && <Login openModal={login} closeModal={closeLogin}/>} */}
        </>
        // </NavContext.Provider>
    )
}


export default Navbar;
