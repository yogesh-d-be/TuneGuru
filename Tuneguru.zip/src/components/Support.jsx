import React  from "react";
// import { Link } from "react-router-dom";

function Support(){

return(
<>

</>
)

}

export default Support;