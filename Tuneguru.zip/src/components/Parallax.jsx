import React, { useEffect}  from "react";
//I stored the gsap cdn link in the index.html file. Then I can use easily gsap globally without import.
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger"
import "./Parallax.css";
// import ParallaxContext from "./ParallaxContext";


//Initialize ScrollTrigger with GSAP
gsap.registerPlugin(ScrollTrigger);

function Parallax() {
  // const parallaxValue = useContext(ParallaxContext); // Using useContext to access the value
useEffect(()=>{
    gsap.from(".im-bg",{
        scrollTrigger:{
            scrub:1,
             // Throttle updates to every 100ms
        },
        scale: 1.4

    });
    gsap.from(".im-bg-1",{
        scrollTrigger:{
            scrub:1,
           // Throttle updates to every 100ms
        },
        scale: 1.4

    });
    // gsap.from(".serv_man",{
    //     scrollTrigger:{
    //         scrub:1
    //     },
    //     scale:0.5
    // })

        gsap.from(".door_l",{
            scrollTrigger:{
                scrub:1,
                 // Throttle updates to every 100ms
            },
            x:-200
        })

        gsap.from(".door_r",{
            scrollTrigger:{
                scrub:1,
                
            },
            x:200
        })

        // gsap.from(".comp",{
        //     scrollTrigger:{
        //         scrub:1
        //     },
        //     y:100
        // })

        // Animation for ".comp" class with scroll direction check
    gsap.to(".comp", {
        scrollTrigger: {
          trigger: ".comp",
          start: "top top",
          end: "bottom top",
          scrub: 1,
          onUpdate: (self) => {
            // Check scroll direction
            const scrollDirection = self.direction;
  
            // Adjust the 'y' property based on scroll direction
            if (scrollDirection === 1) {
              // Scrolling down
              gsap.to(".comp", {
                y: 300, // Move down
                duration: 1.5,
                
              });
            } else {
              // Scrolling up
              gsap.to(".comp", {
                y: 0, // Move back to center
                duration: 1.5,
                
              });
            }
          },
        },
      });

// Refresh ScrollTrigger after dynamic changes
ScrollTrigger.refresh();

},[]);


    return(
      // <ParallaxContext.Provider value={parallaxValue}>
        <>
        <section className="relative w-full h-screen flex justify-center items-center overflow-hidden">
        
            <img src= {require('../assests/images/Service persons.jpeg')} alt="Service persons" className="im-bg absolute top-0 left-50 w-4/6 h-5/6 objcet-cover pointer-events-none mo:hidden ta:hidden de:block des:block"/>
            <img src= {require('../assests/images/Service person-mobile.jpeg')} alt="Service persons" className="im-bg-1 absolute top-0 left-50 w-full h-5/6 objcet-cover pointer-events-none mo:block ta:block ta:w-4/6 de:hidden des:hidden"/>
            <h2 className="relative  text-8xl font-bold comp scroll-smooth  font-bold bg-gradient-to-r from-cyan-500 via-pink-500 to-blue-900  inline-block text-transparent bg-clip-text font-outline-6 mo:text-6xl mo:font-outline-3  ta:text-7xl ta:font-outline-4">TUNEGURU</h2>
            {/* <img src= {require('../assests/images/service.png')} alt="Home Service Person"  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-96 object-cover pointer-events-none serv_man"/> */}
            {/* <img src= {require('../assests/images/AC1.png')} alt="AC1" />
            <img src= {require('../assests/images/AC2.png')} alt="AC2" /> */}
            <img src= {require('../assests/images/Door left.png')} alt="Door left" className="absolute top-0 left-0 w-2/5 h-screen objcet-cover pointer-events-none door_l mo:left-20"/>
            <img src= {require('../assests/images/Door right.png')} alt="Door right" className="absolute top-0 right-0 w-2/5 h-screen objcet-cover pointer-events-none door_r mo:right-20"/>
        </section>
       <div className="relative p-24">
        <h2 className="text-4xl mb-6">Scroll</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque consectetur totam porro repellat eaque nesciunt tempora numquam dolorem voluptatem consequatur pariatur consequuntur tenetur repellendus iusto ipsa nihil voluptas, assumenda omnis.
        Neque, voluptates voluptatem. Explicabo mollitia qui velit, numquam hic quisquam magnam culpa nostrum laudantium minima unde veniam eaque aperiam architecto modi ducimus vel! Culpa magni illo porro, itaque dolore tempora.
        Ratione quae atque ipsam aut accusantium facere in veritatis ducimus. Corrupti a optio iusto, veniam nesciunt odit deleniti similique laboriosam earum alias provident voluptatum eos commodi perferendis dolor, obcaecati architecto?
        Cupiditate placeat delectus nihil nemo blanditiis odit animi corrupti quibusdam, eaque laboriosam at, perspiciatis sed voluptatem! Error, iusto tenetur consectetur eius ipsum dolor reprehenderit earum odit nulla laboriosam, quas porro?
        Dolorum cum atque enim eius aliquam mollitia alias quaerat optio dolore ipsum similique perferendis quis dignissimos maiores omnis voluptatibus repellat, animi non consectetur nostrum autem nam! Sint hic dignissimos aperiam?
        Nobis facere non molestias! Exercitationem nemo at quidem quisquam ullam corrupti qui iusto assumenda? Neque nisi vero in dolore odit tenetur vel, eius commodi, rerum facilis cumque mollitia modi eaque.
        Natus corrupti ex sint laborum aperiam unde. Officia quasi, optio consequatur itaque quo ducimus. Aut architecto provident voluptas! Dolorem odit incidunt consectetur fugiat inventore nesciunt voluptates ea molestiae necessitatibus quas.
        Nostrum officiis dignissimos quia est earum corporis animi incidunt ipsam enim aspernatur molestias error, placeat, unde sed sapiente porro atque blanditiis voluptatibus deleniti, obcaecati ut quibusdam! Odio harum eaque officiis?
        Eaque distinctio, sint deserunt non quisquam laboriosam repellat? Error minus a obcaecati sed non est eaque rem nostrum consectetur? Aliquid et quos cupiditate quas commodi vero iste minus quo non?
        Autem, voluptas dolorum sit, quam neque quibusdam saepe architecto maiores modi et explicabo est cum ducimus. Corporis est quibusdam ullam. Unde quos magni et, cupiditate ipsam sequi reiciendis voluptatibus inventore.
        Doloremque sed dicta hic beatae suscipit quibusdam veniam culpa eos similique accusantium quae facilis officia debitis dignissimos voluptatem et dolorum placeat, ullam, odit deserunt laudantium magnam autem! Consequuntur, autem quaerat.
        Doloremque, dolore! At, fugiat expedita. Quo quia officia sapiente illum, in dolore nulla amet deleniti, tempore minima sit eligendi itaque voluptatibus nisi! Maxime quae, architecto aut facilis alias in aspernatur?
        Necessitatibus itaque, voluptatem reiciendis tempora assumenda nam cum deserunt! Explicabo quam qui voluptatem aut. Maxime, laboriosam, ducimus, voluptates praesentium dolores reiciendis culpa saepe quisquam in dolore voluptatibus unde temporibus ab.
        Dolore expedita iusto neque reprehenderit, iure ducimus earum magnam dignissimos consectetur laboriosam ut dolorum. Magnam aspernatur minima, animi molestias facilis consectetur praesentium. Praesentium voluptatem aut unde sapiente quas. Perferendis, enim.
        Voluptatem, nam veniam exercitationem perspiciatis cum animi porro, veritatis magnam repellat tenetur non laborum sed impedit praesentium, dolore aut dignissimos sint sequi cupiditate distinctio excepturi enim tempore magni! Odio, magni?
        Magni sit nam adipisci fuga! Eius officia impedit similique mollitia. Veniam corrupti excepturi illum atque magnam maiores voluptatum error debitis! Dolore atque unde autem dignissimos officiis voluptatibus sint quas nulla!
        Libero unde accusamus ipsam maxime iste itaque illo veniam pariatur, mollitia qui fugit at ad aperiam possimus numquam voluptates repellat voluptatibus dolorum voluptate quibusdam eum facilis! In consequuntur dolorem eius.
        Fugit quo obcaecati impedit ratione explicabo hic porro laudantium maiores rem, quia quas aperiam illo? Assumenda, ducimus. Beatae eum minima vero veritatis, ab fuga! Quidem doloremque eveniet incidunt vero repudiandae?
        Aspernatur tempore dolore quaerat voluptas veritatis, possimus ut nam quia iste illo vero molestias debitis quidem magni eveniet porro corporis odit rem rerum beatae necessitatibus? Distinctio dolorum expedita doloremque esse.
        Possimus minima sequi dolore facere sunt veritatis asperiores quasi voluptas! Ipsam eos quos libero accusantium? Qui reprehenderit iusto, magnam autem nesciunt libero dolore modi molestiae provident quaerat ad possimus nemo!</p>
       </div>

       

       <script>

       </script>
        </>
        // </ParallaxContext.Provider>
    )
}

export default Parallax;