import React from "react";
// import { Link } from "react-router-dom";
// import NavContext from "./NavContext";
// import Navbar from "./Navbar";
// import ParallaxContext from "./ParallaxContext";
import Parallax from "./Parallax";
import Login from "./Login";
// import {useLocation} from "react-router-dom";


function Home(){
    // const nav = useContext(NavContext)
    // const parallaxValue = useContext(ParallaxContext);
    // const{path} = useLocation();
    // const isHome = path === '/';
    //    const [login, setLogin] = useState(false);

    // const closeLogin = () =>{
    //     setLogin(false);
    // }
return(
<>
{/* {nav} */}
{/* <ParallaxContext.Provider value={Parallax}>
{parallaxValue}
</ParallaxContext.Provider> */}
 {/* <Login openModal={login} closeModal={closeLogin}/> */}
<Parallax/>


</>
)

}

export default Home;