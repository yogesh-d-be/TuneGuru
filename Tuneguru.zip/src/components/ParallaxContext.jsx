// import { createContext } from "react";

// const ParallaxContext = createContext(null);

// export default ParallaxContext;