import React, { useState } from "react";
import Popup from "react-modal";
import { ImCancelCircle } from "react-icons/im";
import { Link } from "react-router-dom";
import "./Navbar.css";

function Login({ visible}) {
  const [isOpen, setIsOpen] = useState(visible);

  const closeModalAndReset = () => {
    setIsOpen(false);
    
  };

  return (
    <>
      <Popup
        isOpen={isOpen}
        onRequestClose={closeModalAndReset}
        style={{
          overlay: {
            background: "rgba(0, 0, 0, 0.662)",
          },
          content: {
            width: "30%",
            height: "45%",
            top: "25%",
            left: "35%",
            right: "35%",
            bottom: "20%",
            borderRadius: "25px",
            boxShadow: "0px 0px 10px black",
            backgroundColor: "rgba(162, 237, 229, 0.732)",
          },
        }}
      >
        <button onClick={closeModalAndReset} className="absolute top-4 right-4">
          <ImCancelCircle className="text-black text-2xl flex justify-right" />
        </button>
        <div className="border-b-2 border-solid border-black">
          <h1 className="font-bold text-2xl mb-4 mt-2 ml-4">LogIn</h1>
        </div>
        <input
          type="text"
          placeholder="Username"
          className="border border-black rounded-lg pl-2 h-8  w-3/4 mt-8 ml-4"
        ></input>
        <br />
        <input
          type="number"
          placeholder="Enter Mobile No"
          className="border border-black rounded-lg pl-2 h-8  w-3/4 mt-8 ml-4 mb-8"
        ></input>
        <br />
        <input
          type="checkbox"
          className="ml-4 text-3xl checked:ring-green-600"
        />
        <span className="ml-2 ">
          I agree to the{" "}
          <Link to="/terms&conditions" className="text-blue-900 font-medium">
            Terms & Conditions
          </Link>
        </span>
      </Popup>
    </>
  );
}

export default Login;
