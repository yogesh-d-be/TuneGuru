import React  from "react";
// import { Link } from "react-router-dom";
// import Parallax from "./Parallax";

function Services(){

return(
<>

</>
)

}

export default Services;